﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SearchEngine_TrainTicketMachine.Respositary
{
   public  static class StationsArray
    {
        public static string[] stations { get; set; }
    }
}
