﻿using System;

namespace TrainTicketMachine.UnitTestCases
{
    public class Class1
    {
    }
}
